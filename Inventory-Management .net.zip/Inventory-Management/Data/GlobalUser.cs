﻿namespace Inventory_Management.Data;

public class GlobalUser
{
    public UserModel CurrentUser { get; set; }
}
