﻿ namespace Inventory_Management.Data;

public enum UserType
{
    Admin,
    Staff
}
