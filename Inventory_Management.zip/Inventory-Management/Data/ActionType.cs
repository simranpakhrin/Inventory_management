﻿namespace Inventory_Management.Data;

public enum ActionType
{
    Pending,
    Approve,
    Reject
}
