﻿namespace Inventory_Management.Data;

public class ItemGraphData
{
    public Guid ItemId { get; set; }
    public string ItemName { get; set; }
    public int Quantity { get; set; }
}
